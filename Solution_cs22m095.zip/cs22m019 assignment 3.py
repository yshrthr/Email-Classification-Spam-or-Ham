#!/usr/bin/env python
# coding: utf-8

# In[1]:


import os
import pandas as pd
import numpy as np 
from sklearn.datasets import load_files
import re
import nltk
nltk.download('stopwords')
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
from nltk.stem import WordNetLemmatizer


# In[2]:


def naive_bayes(X_test,dictionary):
    
    stemmer = PorterStemmer()
    lemmatizer = WordNetLemmatizer()

    for i in range(len(X_test)):
        # Cleaning the data
        review = re.sub(r'\\r\\n', ' ', str(X_test[i]))
        # Remove all symbols except letters
        review = re.sub('[^a-zA-Z]', ' ', review)
        # Replacing all gaps with spaces 
        review = re.sub(r'\s+', ' ', review)   
        # Remove 'b' in the beginning of each text
        review = re.sub(r'^b\s+', '', review)       
        # Converting all text into lowercase
        review = review.lower()
        # Spliting texts
        review = review.split()
        # If the word is not in stopword,take that word 
        for word in review:
            if word not in stopwords.words('english'):
                review = stemmer.stem(word)
        review = ' '.join(review)
        
        # list of words of email
        list_of_words = list(review.split(" "))
        
        
        # Counting the total words in spam and non-spam
        spam_count = 0
        non_spam_count = 0

        # Counting the total words in spam email
        for i in dictionary:
            spam_count += dictionary[i][1]

        # Counting the total words in non-spam email
        for i in dictionary:
            non_spam_count += dictionary[i][0]

        
        # Calculating probability of spam emails
        sum = spam_count + non_spam_count
        prob_spam = spam_count / sum
        
        # Calculating probability of non-spam emails
        prob_non_spam = non_spam_count / sum

        # appyling naive bayes if the word in email is in given dictionary
        prob_N_xTest = prob_non_spam
        for word in list_of_words:
            if word in dictionary.keys():
                prob_N_xTest *= (dictionary[word][0] / non_spam_count)

        prob_S_xTest = prob_spam
        for word in list_of_words:
            if word in dictionary.keys():
                prob_S_xTest *= (dictionary[word][1] / spam_count)

        # if prob_N_xTest > prob_S_xTest then email is non-spam else it is spam
        y_test = 1
        if(prob_N_xTest > prob_S_xTest):
            y_test = 0
        if(y_test == 1):
            print("1")
        else:
            print("0")


# In[3]:


# Training the data
X, y = [], []
email = load_files("./train")
X_train = np.append(X, email.data)
y_train = np.append(y, email.target)

X = X_train
y = y_train

# Extracting labels and text from train dataset
df_all = pd.DataFrame(columns=['text', 'label'])
df_all['text'] = [l for l in X]
df_all['label'] = [t for t in y]

# Extracting text in df_X and labels in df_y
df_X = df_all.drop(['label'], axis=1)
df_y = df_all['label']

stemmer = PorterStemmer()
lemmatizer = WordNetLemmatizer()

# Creating corpus which removes unneccesary symbols from text
corpus = []
for i in range(0, len(df_X)):

    # Removing special symbols
    review = re.sub(r'\\r\\n', ' ', str(df_X['text'][i]))
  
    # Remove all symbols except letters
    review = re.sub('[^a-zA-Z]', ' ', review)
  
    # Replacing all gaps with spaces 
    review = re.sub(r'\s+', ' ', review)                    
  
    # Remove 'b' in the beginning of each text
    review = re.sub(r'^b\s+', '', review)       

    # Converting all text into lowercase
    review = review.lower()

    # Spliting texts
    review = review.split()

    # If the word is not in stopword,take that word 
    for word in review:
        if word not in stopwords.words('english'):
            review = stemmer.stem(word)
    review = ' '.join(review)

    # Corpus stores all emails where each email is a string of stem words seperated by spaces
    corpus.append(review)

# Generating a set of unique words
set_of_words = set()
for i in range(len(corpus)):
    words = list(corpus[i].split(" "))
    for i in range(len(words)):
        set_of_words.add(words[i])

# Generating dictionary where each word has 2 values,its count in spam email and count in non-spam email
dictionary = {}
for i in set_of_words:
    dictionary[i] = [1,1]

# Updating dictionary to store count of each word whether is belongs to spam or non-spam
for i in range(len(corpus)):
    spam_non_spam = int(y[i])
    words = list(corpus[i].split(" "))
  
    for j in range(len(words)):
        dictionary[words[j]][spam_non_spam] += 1


# In[4]:


# reading the text file
def read_text_file(filepath):
     with open (filepath,'r',errors = "ignore") as file:
        return str(file.read())


# In[5]:


# Testing the data and appyling naive bayes on test data and given dictionary
X = []
test_folder = "test"
for file in sorted(os.listdir(test_folder)):
    file_path = f"{test_folder}\{file}"
    X.append(read_text_file(file_path))
    
naive_bayes(X,dictionary)


# In[9]:




